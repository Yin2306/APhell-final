import type { Express } from "express";
import { createServer, type Server } from "http";
import { exec } from "child_process";
import { promisify } from "util";

const execAsync = promisify(exec);

export async function registerRoutes(
  httpServer: Server,
  app: Express
): Promise<Server> {
  app.get("/api/validate/:code", async (req, res) => {
    const { code } = req.params;
    
    if (!/^\d{3}$/.test(code)) {
      return res.status(400).json({
        success: false,
        message: "Invalid code format - must be 3 digits"
      });
    }

    try {
      const { stdout, stderr } = await execAsync(`python main.py ${code}`);
      
      const lines = stdout.split('\n');
      const results: { name: string; status: "success" | "error"; message?: string }[] = [];
      
      let currentName = "Unknown";
      lines.forEach(line => {
          const nameMatch = line.match(/Processing: (.*) \(/);
          const successMatch = line.match(/Processing: (.*) \(Success\)/);
          
          if (nameMatch) {
              currentName = nameMatch[1];
          }
          
          if (successMatch) {
              const name = successMatch[1];
              // Avoid duplicates if both patterns match same line
              if (!results.find(r => r.name === name)) {
                  results.push({ name, status: "success" });
              }
          } else if (line.startsWith("ERROR:")) {
              const errorParts = line.replace("ERROR: ", "").split(": ");
              const name = errorParts[0];
              const msg = errorParts.slice(1).join(": ");
              results.push({ 
                  name, 
                  status: "error", 
                  message: msg
              });
          }
      });

      return res.json({
        success: results.length > 0 && results.every(r => r.status === "success"),
        results
      });
    } catch (error: any) {
      console.error("Execution error:", error);
      return res.status(500).json({
        success: false,
        message: "Failed to process attendance"
      });
    }
  });

  return httpServer;
}
