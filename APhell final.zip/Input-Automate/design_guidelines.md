# OTP Auto-Validation App - Design Guidelines

## Design Approach
**Selected Approach**: Design System (Modern Authentication UI)
**Reference Inspiration**: Stripe authentication, Vercel login screens, modern banking 2FA interfaces
**Core Principle**: Clarity and immediate feedback over decoration

## Design Decision Rationale
This is a utility-focused application where efficiency and clear feedback are paramount. The interface should minimize cognitive load and provide instant, unmistakable validation results.

---

## Typography

**Font Family**: 
- Primary: Inter or SF Pro (Google Fonts via CDN)
- Monospace: JetBrains Mono for OTP digits

**Type Scale**:
- Heading (App title): text-2xl, font-semibold
- Instructions: text-base, font-normal
- OTP digits: text-4xl, font-bold, monospace
- Feedback message: text-sm, font-medium
- Error text: text-xs, font-normal

---

## Layout System

**Spacing Units**: Tailwind units of 2, 4, 6, 8, 12, 16
- Component padding: p-6
- Section spacing: space-y-8
- Input spacing: gap-4
- Tight groupings: space-y-2

**Container Structure**:
- Centered card layout: max-w-md mx-auto
- Vertical centering: min-h-screen flex items-center justify-center
- Mobile-first with comfortable touch targets (min 44px height)

---

## Core Components

### OTP Input Section
**Layout**: Individual digit boxes in horizontal row
- Each box: w-14 h-14 (large touch targets)
- Gap between boxes: gap-3
- Border treatment: 2px border, rounded-lg
- Focus ring: ring-2 with offset
- Text alignment: centered, monospace font

**Input Container**:
- Grid layout for consistent spacing: grid grid-cols-[repeat(auto-fit,minmax(3.5rem,1fr))]
- Max width to prevent over-stretching: max-w-sm mx-auto

### Validation Feedback
**Position**: Directly below OTP input (mt-6)
**Components**:
- Icon: 24px size (w-6 h-6) - Use Heroicons via CDN
- Success: CheckCircleIcon (solid)
- Error: XCircleIcon (solid)
- Message text beside icon: flex items-center gap-2

**Feedback States**:
- Success container: flex items-center with success treatment
- Error container: flex items-center with error treatment
- Loading state: Spinner icon (w-5 h-5 animate-spin)

### Loading Indicator
**Display**: During validation (between input complete and result)
- Small spinner below input field
- Text: "Validating..." in muted treatment

---

## Component Library

### Primary Container
- Card-style container with subtle shadow
- Padding: p-8 on desktop, p-6 on mobile
- Rounded corners: rounded-2xl
- Background: distinct from page background

### Header Section
- App title/logo at top
- Instruction text below: "Enter your verification code"
- Spacing: space-y-4

### Input Group
- Label above input (if needed): text-sm font-medium
- OTP digit boxes with consistent styling
- Help text below (if needed): text-xs in muted treatment

### Footer/Helper Section
- "Didn't receive code?" link
- Resend functionality (optional)
- Small text: text-xs

---

## Interaction Patterns

### Auto-Focus Behavior
- First input box auto-focused on page load
- Auto-advance to next box on digit entry
- Auto-submit on final digit entry

### Validation Flow
1. User completes typing → Immediate loading state appears
2. Backend validates → Show spinner (0.5-2s)
3. Result received → Show success/error with icon

### Error Recovery
- Allow immediate re-typing on error
- Clear previous error when user starts typing again
- Optionally clear input on error for retry

---

## Visual Hierarchy

**Primary Focus**: OTP input boxes (largest, most prominent)
**Secondary**: Validation feedback (high contrast, clear icons)
**Tertiary**: Instructions, helper text (muted, smaller)

**Contrast Principles**:
- High contrast for interactive elements
- Medium contrast for body text
- Low contrast for helper text

---

## Accessibility

- Minimum 44px touch targets for mobile
- Clear focus indicators (2px ring offset)
- ARIA labels for screen readers
- Keyboard navigation support (arrow keys between boxes)
- High contrast ratios for text (4.5:1 minimum)
- Error messages announced to screen readers

---

## Icons
**Library**: Heroicons (via CDN)
**Icons Used**:
- CheckCircleIcon (success feedback)
- XCircleIcon (error feedback)
- ArrowPathIcon (loading spinner)

---

## Responsive Behavior

**Mobile** (default):
- Single column layout
- OTP boxes: 56px × 56px (w-14 h-14)
- Container padding: p-6
- Full-width within max-w-md

**Desktop** (md: breakpoint):
- Same centered layout
- Slightly larger padding: p-8
- No significant layout changes (app is inherently simple)

---

## Animation Guidelines
**Minimal, Purposeful Only**:
- Loading spinner rotation (animate-spin)
- Smooth opacity transition for feedback appearance (transition-opacity)
- NO elaborate entrance animations
- NO unnecessary micro-interactions