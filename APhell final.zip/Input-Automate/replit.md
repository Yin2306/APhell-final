# OTP Auto-Validation App

## Overview
A verification code input application that automatically validates codes when the user finishes typing. No submit button needed - just type the code and see instant feedback.

## How It Works
1. User types a 3-digit code into the OTP input boxes
2. When all 3 digits are entered, the app automatically sends the code to the backend
3. Backend runs `main.py` Python script to validate the code
4. Frontend displays green checkmark (success) or red X (error) below the input

## Project Structure
```
├── client/src/
│   ├── pages/
│   │   └── otp-validation.tsx    # Main OTP input page
│   └── components/
│       └── ValidationFeedback.tsx # Success/error display component
├── server/
│   └── routes.ts                  # API endpoint /api/validate/:code
├── main.py                        # Python validation script (customize this!)
```

## Customizing Validation Logic

Edit `main.py` to add your own validation logic. The current implementation accepts these codes:
- "123" - Valid
- "456" - Valid  
- "789" - Valid
- Any other code - Invalid

### Example customizations:
```python
def validate_code(code: str) -> bool:
    # Example 1: Check against a database
    # return db.check_code(code)
    
    # Example 2: Call an external API
    # response = requests.get(f"https://api.example.com/verify/{code}")
    # return response.json()["valid"]
    
    # Example 3: Simple static list
    valid_codes = ["123", "456", "789"]
    return code in valid_codes
```

## API Reference

### GET /api/validate/:code
Validates an OTP code.

**Response:**
```json
{
  "success": true,
  "message": "Code verified successfully"
}
```
or
```json
{
  "success": false,
  "message": "Invalid code, please try again"
}
```

## Running the App
The app runs on port 5000 with `npm run dev`.

## Recent Changes
- **2024-12-10**: Initial implementation with auto-validation, AbortController for race condition handling, Python script integration
