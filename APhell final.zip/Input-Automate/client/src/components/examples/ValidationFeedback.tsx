import { ValidationFeedback } from "../ValidationFeedback";

export default function ValidationFeedbackExample() {
  return (
    <div className="flex flex-col gap-4 p-6">
      <ValidationFeedback status="loading" />
      <ValidationFeedback status="success" message="Code verified successfully" />
      <ValidationFeedback status="error" message="Invalid code, please try again" />
    </div>
  );
}
