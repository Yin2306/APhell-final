import OTPValidation from "../../pages/otp-validation";

export default function OTPValidationExample() {
  return <OTPValidation />;
}
