import { CheckCircle, XCircle, Loader2 } from "lucide-react";
import { cn } from "@/lib/utils";

export type ValidationStatus = "idle" | "loading" | "success" | "error";

export interface AccountResult {
  name: string;
  status: "success" | "error";
  message?: string;
}

interface ValidationFeedbackProps {
  status: ValidationStatus;
  message?: string;
  results?: AccountResult[];
  totalAccounts?: number;
  className?: string;
}

export function ValidationFeedback({ status, message, results, totalAccounts = 8, className }: ValidationFeedbackProps) {
  if (status === "idle") {
    return null;
  }

  const completedCount = results?.length || 0;
  const pendingCount = totalAccounts - completedCount;
  const successCount = results?.filter(r => r.status === "success").length || 0;
  const failCount = results?.filter(r => r.status === "error").length || 0;

  return (
    <div
      className={cn(
        "w-full flex flex-col gap-4 transition-opacity duration-200",
        className
      )}
      data-testid="validation-feedback"
    >
      {status === "loading" && (
        <div className="space-y-3">
          <div className="flex items-center justify-center gap-2">
            <Loader2 className="h-5 w-5 animate-spin text-primary" data-testid="icon-loading" />
            <span className="text-sm font-medium text-foreground">Processing attendance...</span>
          </div>
          {completedCount > 0 && (
            <div className="text-xs text-center text-muted-foreground">
              <span className="font-semibold text-green-600 dark:text-green-400">{successCount}</span> done, 
              <span className="font-semibold ml-1">{pendingCount}</span> remaining
            </div>
          )}
        </div>
      )}

      {status !== "loading" && results && results.length > 0 && (
        <div className="space-y-2 max-h-[300px] overflow-y-auto pr-2 custom-scrollbar">
          {results.map((result, idx) => (
            <div 
              key={idx}
              className={cn(
                "flex items-center justify-between p-3 rounded-lg border animate-in fade-in slide-in-from-top-2 duration-300",
                result.status === "success" 
                  ? "bg-green-50/50 border-green-100 dark:bg-green-950/20 dark:border-green-900/30" 
                  : "bg-red-50/50 border-red-100 dark:bg-red-950/20 dark:border-red-900/30"
              )}
            >
              <div className="flex items-center gap-2">
                {result.status === "success" ? (
                  <CheckCircle className="h-4 w-4 text-green-500" />
                ) : (
                  <XCircle className="h-4 w-4 text-red-500" />
                )}
                <span className="text-sm font-medium">{result.name}</span>
              </div>
              <span className={cn(
                "text-xs",
                result.status === "success" ? "text-green-600 dark:text-green-400" : "text-red-600 dark:text-red-400"
              )}>
                {result.status === "success" ? "Success" : "Failed"}
              </span>
            </div>
          ))}
        </div>
      )}

      {status === "error" && (!results || results.length === 0) && (
        <div className="flex items-center justify-center gap-2">
          <XCircle className="h-5 w-5 text-red-500" data-testid="icon-error" />
          <span className="text-sm font-medium text-red-600 dark:text-red-400">
            {message || "System error, please try again"}
          </span>
        </div>
      )}
    </div>
  );
}
