import { useState, useCallback, useRef, useEffect } from "react";
import { InputOTP, InputOTPGroup, InputOTPSlot } from "@/components/ui/input-otp";
import { ValidationFeedback, ValidationStatus, AccountResult } from "@/components/ValidationFeedback";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";

const OTP_LENGTH = 3;

export default function OTPValidation() {
  const [value, setValue] = useState("");
  const [status, setStatus] = useState<ValidationStatus>("idle");
  const [message, setMessage] = useState("");
  const [results, setResults] = useState<AccountResult[]>([]);
  
  const abortControllerRef = useRef<AbortController | null>(null);

  useEffect(() => {
    return () => {
      abortControllerRef.current?.abort();
    };
  }, []);

  const validateCode = useCallback(async (code: string) => {
    abortControllerRef.current?.abort();
    const controller = new AbortController();
    abortControllerRef.current = controller;
    
    setStatus("loading");
    setMessage("");
    setResults([]);

    try {
      const response = await fetch(`/api/validate/${code}`, {
        signal: controller.signal
      });
      
      if (controller.signal.aborted) return;
      
      const data = await response.json();

      if (response.ok) {
        if (data.results) {
          setResults(data.results);
          const anyFail = data.results.some((r: any) => r.status === "error");
          setStatus(anyFail ? "error" : "success");
        } else {
          setStatus(data.success ? "success" : "error");
          setMessage(data.message);
        }
      } else {
        setStatus("error");
        setMessage(data.message || "Invalid code, please try again");
      }
    } catch (error: any) {
      if (error.name === "AbortError") return;
      setStatus("error");
      setMessage("Connection error, please try again");
    }
  }, []);

  const handleChange = useCallback((newValue: string) => {
    setValue(newValue);
    
    if (status === "success" || status === "error") {
      setStatus("idle");
      setMessage("");
      setResults([]);
    }

    if (newValue.length === OTP_LENGTH) {
      validateCode(newValue);
    }
  }, [status, validateCode]);

  const handleRetry = useCallback(() => {
    abortControllerRef.current?.abort();
    abortControllerRef.current = null;
    setValue("");
    setStatus("idle");
    setMessage("");
    setResults([]);
  }, []);

  return (
    <div className="min-h-screen flex items-center justify-center bg-background p-4 safe-area-inset">
      <Card className="w-full max-w-md border-2 shadow-lg">
        <CardHeader className="text-center space-y-2 pt-8">
          <CardTitle className="text-3xl font-extrabold tracking-tight text-primary" data-testid="text-title">
            APSpace
          </CardTitle>
          <CardDescription className="text-muted-foreground font-medium" data-testid="text-description">
            Enter 3-digit OTP to check-in
          </CardDescription>
        </CardHeader>
        <CardContent className="flex flex-col items-center space-y-8 pb-10">
          <div className="w-full flex justify-center py-4">
            <InputOTP
              maxLength={OTP_LENGTH}
              value={value}
              onChange={handleChange}
              disabled={status === "loading"}
              data-testid="input-otp"
              autoFocus
              inputMode="numeric"
              pattern="\d*"
            >
              <InputOTPGroup className="gap-4">
                {Array.from({ length: OTP_LENGTH }).map((_, index) => (
                  <InputOTPSlot
                    key={index}
                    index={index}
                    className="h-20 w-16 text-4xl font-bold font-mono rounded-2xl border-2 shadow-sm ring-offset-4 focus-visible:ring-primary transition-all duration-200"
                    data-testid={`input-otp-slot-${index}`}
                  />
                ))}
              </InputOTPGroup>
            </InputOTP>
          </div>

          <ValidationFeedback status={status} message={message} results={results} />

          {(status === "error" || status === "success") && (
            <button
              onClick={handleRetry}
              className="w-full max-w-[200px] h-12 flex items-center justify-center rounded-xl bg-secondary text-secondary-foreground font-semibold hover:bg-secondary/80 active:scale-95 transition-all mt-4"
              data-testid="button-retry"
            >
              Reset for Next
            </button>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
