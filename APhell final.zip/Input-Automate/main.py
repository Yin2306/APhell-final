import re
from sys import argv
import requests
from yaml import safe_load
from concurrent.futures import ThreadPoolExecutor, as_completed
import signal

class TimeoutException(Exception):
    pass

def timeout_handler(signum, frame):
    raise TimeoutException("Processing timeout - stopping remaining requests")

class Account:
    TGT_URL = "https://cas.apiit.edu.my/cas/v1/tickets"
    TGT_PATTERN = r'TGT-[^"]*'
    ATTENDIX_SERVICE_URL = "https://api.apiit.edu.my/attendix"
    ATTENDIX_URL = "https://attendix.apu.edu.my/graphql"

    def __init__(self, username: str, password: str, api_key: str) -> None:
        self.username = username
        self.password = password
        self.api_key = api_key
        self.tgt = None
        self.service_ticket = None

    def login(self) -> None:
        data = {"username": self.username, "password": self.password}
        response = requests.post(self.TGT_URL, data, timeout=10)
        match = re.search(self.TGT_PATTERN, response.text)
        if not match:
            raise ValueError(f"Failed to get TGT for {self.username}")
        self.tgt = match.group()

    def get_service_ticket(self, service: str) -> None:
        if not self.tgt:
            raise ValueError("TGT not found")
        url = f"{self.TGT_URL}/{self.tgt}?service={service}"
        headers = {"Content-Type": "application/x-www-form-urlencoded"}
        response = requests.post(url, headers=headers, timeout=10)
        if not response.text:
            raise ValueError(f"Failed to get service ticket for {self.username}")
        self.service_ticket = response.text

    def take_attendance(self, otp: str) -> None:
        if not self.service_ticket:
            raise ValueError("Service ticket not found")
        json = {
            "operationName": "updateAttendance",
            "query": "mutation updateAttendance($otp: String!) {\n  updateAttendance(otp: $otp) {\n    id\n    attendance\n    classcode\n    date\n    startTime\n    endTime\n    classType\n    __typename\n  }\n}\n",
            "variables": {"otp": otp},
        }
        headers = {"Ticket": self.service_ticket, "x-api-key": self.api_key}
        response = requests.post(self.ATTENDIX_URL, json=json, headers=headers, timeout=10)
        response_dict = response.json()
        if "errors" in response_dict:
            messages = (error["message"] for error in response_dict["errors"])
            raise ValueError(f"Failed: {'; '.join(messages)}")

def process_single_account(account_dict, otp):
    account_name = account_dict.pop('name', 'Unknown')
    print(f"Processing: {account_name} ({account_dict.get('username')})")
    try:
        account = Account(**account_dict)
        account.login()
        account.get_service_ticket(Account.ATTENDIX_SERVICE_URL)
        account.take_attendance(otp)
        print(f"Processing: {account_name} (Success)")
        return True
    except Exception as e:
        print(f"ERROR: {account_name}: {e}")
        return False

def bulk_login_and_take_attendance(account_file_path: str, otp: str) -> None:
    with open(account_file_path) as file:
        accounts = safe_load(file)
    
    if not otp.isdigit() or len(otp) != 3:
        raise ValueError(f"Invalid OTP '{otp}'")

    # Set timeout to 30 seconds per account max
    signal.signal(signal.SIGALRM, timeout_handler)
    signal.alarm(30)
    
    try:
        # Parallel processing using ThreadPoolExecutor
        with ThreadPoolExecutor(max_workers=len(accounts)) as executor:
            list(executor.map(lambda acc: process_single_account(acc, otp), accounts))
    finally:
        signal.alarm(0)  # Cancel alarm
    
    print("Done")

def main() -> None:
    account_file_path = "accounts.yaml"
    if len(argv) < 2:
        raise ValueError("Usage: python main.py <otp>")
    otp = argv[1]
    bulk_login_and_take_attendance(account_file_path, otp)

if __name__ == "__main__":
    main()
